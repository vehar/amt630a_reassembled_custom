/*******************************************************************************
*Copyright (C) 2005 ���ڰ��ƴ������޹�˾��ƷӦ��һ��
* All rights reserved.

*File name: �� DianWeiQiKeyPad.h  
*Version:      0.1
*update:       2012-03-12
*Description:
  		   ���ļ��Ƕ�DIANWEIQI �����Ĳɼ��봦��ͷ�ļ���

*History:  yshuizhou   2012/03/12    0.1    build  this  moudle
******************************************************************************/
#ifndef  _DIANWEIQI_KEY_PAD_H__
#define  _DIANWEIQI_KEY_PAD_H__

#ifdef KeyDetectEn 
#if KEY_TYPE == DIANWEIQI_KEY

#ifdef _DIANWEIQI_KEY_PAD_C_
#define _DIANWEIQI_KP_EXTERN_ 
#else
#define _DIANWEIQI_KP_EXTERN_ extern
#endif


#define DianWeiQiChannelBit           (_BIT12|_BIT13) //��λ��ͨ����Ϣ
#define DianWeiQiAdjMaxStep           60    //�ɼ���λ��ADCʵ�ʵ��ڽ�������ֵ���������޸ġ�


_DIANWEIQI_KP_EXTERN_ UINT POS_GetBestDianWeiQiKeyVal(UINT* AdcBuf, UCHAR Length);
_DIANWEIQI_KP_EXTERN_ UINT  POS_FilterDianWeiQiKeyVal(UINT * AdcValueBuf,UCHAR len);
_DIANWEIQI_KP_EXTERN_ UINT  POS_GetDianWeiQiKeyValue(void);
_DIANWEIQI_KP_EXTERN_ void POS_InitDianWeiQiKey(void);
_DIANWEIQI_KP_EXTERN_ UINT SelDianWeiQiChannelVal(UCHAR Channel);
_DIANWEIQI_KP_EXTERN_ void UpdataDianWeiQiInitPara(UCHAR curChannel);
_DIANWEIQI_KP_EXTERN_ KeyInfor POS_TransferDianWeiQiKeyMsg(UINT KeyVal);
_DIANWEIQI_KP_EXTERN_ void POS_InitDianWeiQiKeyMsg(void);

#endif  //#if KEY_TYPE == ADC_KEY
#endif   //#ifdef KeyDetectEn 
#endif   // #ifndef  _ADC_KEY_PAD_H__
