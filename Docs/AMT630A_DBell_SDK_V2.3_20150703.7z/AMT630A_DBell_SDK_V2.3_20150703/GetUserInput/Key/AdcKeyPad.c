/*******************************************************************************
*Copyright (C) 2005 ���ڰ��ƴ������޹�˾��ƷӦ��һ��
* All rights reserved.

*File name: �� AdcKeyPad.c	  
*Version:      0.1
*update:       2011-12-08
*Description:
  		   ���ļ��Ƕ�ADC �����Ĳɼ��봦����

*History:  Jordan.chen   2011/12/08    0.1    build  this  moudle
******************************************************************************/
#define _ADC_KEY_PAD_C_

#include "DataType.h"
#include "global.h"
#include "MsgMap.h"
#include "systemConfig.h"
#include "Debug.h"
#include "AdcKeyPad.h"
#include "AMT_Reg.h"
#include "AMT_Drv.h"


#ifdef KeyDetectEn 
#if KEY_TYPE == ADC_KEY

#include "KeypadMap.h"


static UCHAR  XDATA s_ucPreChannel;


/*************************************************************************
name:    GetBestAdcKeyVal(UCHAR* AdcBuf, UCHAR Length)
input:   AdcBuf  //���˲�������ָ�롣
         Length  //���˲������ݳ��ȡ�
output:	 ����ƽ������ƽ���˲�������ݡ�
update�� 2011-12-07
state��  try out
description: ����ƽ������ƽ���˲�������ݡ�

history: yshuizhou   2011/12/20    0.2    build  this  function
*************************************************************************/
UINT POS_GetBestAdcKeyVal( UINT * AdcBuf, UCHAR Length)
{
	UCHAR XDATA i,j,index;
	UINT XDATA s_offset1 = 0,s_offset2 = 0;
	
	 for(i=0; i<Length; i++)
	 {
	    s_offset1 += Abs(AdcBuf[i], AdcBuf[0]);
	 }
	index = 0;
	for(i=1; i<Length; i++)
	{
	    for(j=0; j<Length;j++)
	    {
	        s_offset2 += Abs(AdcBuf[i], AdcBuf[j]);
	    }
	    if(s_offset1 > s_offset2)
	    {
	        s_offset1 = s_offset2;
		    index = i;
	    }
	    s_offset2 = 0;	
	}	
	return AdcBuf[index];
}


/*************************************************************************
name:    FilterAdcKeyVal(UINT * AdcValueBuf,UCHAR len)
input:   AdcValueBuf��len��
output:	 ����ƽ������ƽ���˲�������ݡ�
update�� 2011-11-28
state��  try out
description:  ���������ADC���͵İ����˲������������޸��˲�������Ӧ�İ���ֵ�� 

history: yshuizhou   2011/12/20    0.2    build  this  function
*************************************************************************/
UINT POS_FilterAdcKeyVal(UINT * AdcValueBuf,UCHAR len)
{    

	 UCHAR XDATA  i,j;
	 UINT  XDATA CurrentKey;
	 FLAG  Keyok = TRUE;
	 
	for(i=0;i<(len-1);i++)
 	{
		for(j=i+1;j<len;j++)
		 {
			 if(Abs(AdcValueBuf[i],AdcValueBuf[j]) > 13)   //��������ADC �ɼ���ѹ���ܳ���0.1V
			 {
				Keyok = FALSE;
				break;
			 }
		 }
		if(!Keyok)
		{
		   break;
		}
    }
	
	if(Keyok)
 	{
 	     CurrentKey = POS_GetBestAdcKeyVal(AdcValueBuf,len);
		 CurrentKey = setFlg(CurrentKey,KeyOkFlg);
 	}
    else
    {
		 CurrentKey = clrFlg(CurrentKey,KeyOkFlg);
    }
	return(CurrentKey);		
	
}



/*************************************************************************
name:    ReleaseAdcKey(UINT AdcKeyVal)
input:   AdcKeyVal
output:	 NULL_KEY
update�� 2011-12-07
state��  try out
description: ADC�����ͷţ�ִ����صĲ�����

history: yshuizhou   2011/12/07    0.2    build  this  function
*************************************************************************/
UINT POS_ReleaseAdcKey(UINT AdcKeyVal)
{
    if((readFlg(AdcKeyVal,AdcChannelBit)>>12) == s_ucPreChannel)
    {
       //printfStr("Release Adc Key");
	   g_bKeyRepeatFlg = FALSE;
       PreKey.PressTime = NULL_TIME;
	   PreKey.KeyMsg = MSG_NULL;
    }
	return NULL_KEY;
}



/***********************************************************
*name:     GetAdcKeyValue(void)
*input:    non
*return:   ���ص�ǰͨ���ɼ����ð���ֵ��
*update:   2011-12-22
*state:   try out
*description:   
         ���������ʱ��ȡADC����ͨ���İ���ֵ�� 

         
*history:yshuizhou   2011/12/20    0.2    build  this  function	
************************************************************/
UINT POS_GetAdcKeyValue(void)
{   
    static UCHAR    CODE  ChannelBuf[] = ADC_CH_LIST;
	static UINT     XDATA AdcKeyValBuf[] = {0XFFFF,0XFFFF,0XFFFF,0XFFFF};
    static UCHAR    XDATA AdcChannel = 0;
	static UCHAR    XDATA Index = 0;	
	UINT  XDATA CurrentAdcVal;

	
    AdcKeyValBuf[Index] = POS_EnableChipAdc(ChannelBuf[AdcChannel])>>4;
	Index++;
	
	if(Index >= (sizeof(AdcKeyValBuf)/2)) //note:����������Ϊint 
	{  
	   Index = 0; 
	   CurrentAdcVal = POS_FilterAdcKeyVal(AdcKeyValBuf,sizeof(AdcKeyValBuf)/2);
	   CurrentAdcVal |= (((UINT)(ChannelBuf[AdcChannel]))<<12);//����ͨ����Ϣ��

	   if(readFlg(CurrentAdcVal , KeyOkFlg) == KeyOkFlg)
	   {    
           #if TP1_ADC
		   printf("TP1_ADC >> the KeyValue is %x:\r\n",clrFlg(CurrentAdcVal , KeyOkFlg));				 
           #endif
		   
	       #if hw_upResistance
           if((CurrentAdcVal &0X00FF) >=0X00F0) // ����״̬   (�����ӷ�)
           #endif
		   
		   #if hw_downResistance
		   if((CurrentAdcVal &0X00FF) == 0X0000) // ����״̬ (�����ӷ�)
		   #endif
           {
               	AdcChannel++;
				
				if(AdcChannel >= (sizeof(ChannelBuf))) 
				{
				   AdcChannel = 0;
				}
			   return (POS_ReleaseAdcKey(clrFlg(CurrentAdcVal , KeyOkFlg)));
           }
	       else   //����״̬
		   {   	
		     
               #if TP2_ADC
		       printf("TP2_ADC >> the KeyValue is %x:\r\n",clrFlg(CurrentAdcVal , KeyOkFlg));				 
               #endif
			   
		       return (clrFlg(CurrentAdcVal , KeyOkFlg));
		   }
	   }
	}
	return NULL_KEY;
}



/***********************************************************
*name:     	 TransferAdcKeyCmd(UINT KeyVal)
*input:      AdcKeyVal
*output:     ���ض�Ӧ����ֵ�ĺ����
*update:     2011-12-22

*description:   
         ��������Ǹ��ݵ�ǰ����ֵ��SysKeyCmdMapӳ����в�����Ӧ�İ������
*history:yshuizhou   2012/01/06    0.2    build  this  function	
************************************************************/
UCHAR POS_TransferAdcKeyCmd(UINT KeyVal)
{
     UCHAR XDATA i,j;
	 UCHAR XDATA KeyCmd  = NULL_CMD;

	 for(i = 0; i < sizeof(SysAdcKeyCmdMap)/sizeof(SysAdcKeyCmdMap[0]); i++)
	 {
	    if(NULL_KEY == SysAdcKeyCmdMap[i].KeyVal)
	    {
	        continue;
	    }
			
		if(readFlg(SysAdcKeyCmdMap[i].KeyVal,AdcChannelBit) == readFlg(KeyVal,AdcChannelBit))
		{   	
		    if( 0X00 == KeyVal)
		    {
		       	 for(j = 0; j < sizeof(SysAdcKeyCmdMap)/sizeof(SysAdcKeyCmdMap[0]); j++)
		       	 {
		       	    if(NULL_KEY == SysAdcKeyCmdMap[j].KeyVal)
				    {
				        continue;
				    }

					if(KeyVal == SysAdcKeyCmdMap[j].KeyVal)
					{
					    s_ucPreChannel = (UCHAR)(readFlg(KeyVal,AdcChannelBit)>>12);
		                KeyCmd =  SysAdcKeyCmdMap[j].KeyCmd;

                        #if TP3_ADC
						printf("Special Zero TP3_ADC >> Adc Key Macro val = %x", KeyCmd);
                        #endif

						break;
					}
		       	 }
		    }
			else
			{
			    if(Abs(SysAdcKeyCmdMap[i].KeyVal,KeyVal) < KEY_OFFSET)
				{    				 
				     s_ucPreChannel = (UCHAR)(readFlg(KeyVal,AdcChannelBit)>>12);
		             KeyCmd =  SysAdcKeyCmdMap[i].KeyCmd;
					 
					 #if TP3_ADC
					 printf("TP3_ADC >> Adc Key Macro val = %x", KeyCmd);
					 #endif
					 
					 break;
				}
			}
		}
	 }
   return KeyCmd;
}



/***********************************************************
*name:     	 POS_TransferAdcKeyMsg(UINT AdcKeyVal)
*input:      AdcKeyVal
*output:     ���ض�Ӧ����ֵ����Ϣ
*update:     2011-12-22

*description:   
         ��������Ǹ��ݵ�ǰ����ֵ��SysKeyMapӳ����в�����Ӧ�İ�����Ϣ��
*history:yshuizhou   2012/01/06    0.2    build  this  function	
************************************************************/
KeyInfor POS_TransferAdcKeyMsg(UCHAR KeyCmd)
{    
     UCHAR XDATA i;
	 KeyInfor XDATA Key ={MSG_NULL,NULL_TIME};
			
	for(i = 0; i < sizeof(SysAdcKeyMsgMap)/sizeof(SysAdcKeyMsgMap[0]); i++)  
    {
        if(SysAdcKeyMsgMap[i].KeyCmd == NULL_CMD)
        {
            continue;
        }

	    if(KeyCmd == SysAdcKeyMsgMap[i].KeyCmd)
	    {    				 	 					 
		   Key.KeyMsg = SysAdcKeyMsgMap[i].KeyMsg;

		   if(PreKey.KeyMsg !=Key.KeyMsg)
		   {
		       PreKey.KeyMsg = Key.KeyMsg;
			   g_UserInputInfo.Status = inputPress;
		   }
		   else
		   {    
		        if(g_bKeyRepeatFlg)
		        {
				   g_UserInputInfo.Status = inputHold;
		        }
                else
                {
	                if(++PreKey.PressTime == RepeatTime)
			        {
			            g_bKeyRepeatFlg = TRUE;
			        }
					Key.KeyMsg = MSG_NULL;
                }
		   }		  
		 }
	}

	#if TP1_KEY
    printf("TP1_KEY >> the KeyMsg is %x:\r\n",Key.KeyMsg);				 
	#endif

	return Key;
}

#endif   //#if KEY_TYPE == ADC_KEY
#endif   //#ifdef KeyDetectEn 

