 /*ϵͳ������LOGO�б�*/ 
#include"DataType.h"
#include "systemConfig.h"
LogoInfoType CODE LogoList[] = 
{ 
{LOGO1,1,0x18,0x00  },

{LOGO2,0,0x77,0x1220},
};