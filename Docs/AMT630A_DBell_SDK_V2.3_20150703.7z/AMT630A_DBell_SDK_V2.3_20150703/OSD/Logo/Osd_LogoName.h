#include"DataType.h"
#include "systemConfig.h"
UCHAR* CODE FactorySwitchMenu_SwitchLogoIdStr[] = 
{ 
" ARK",
"Auto",
};