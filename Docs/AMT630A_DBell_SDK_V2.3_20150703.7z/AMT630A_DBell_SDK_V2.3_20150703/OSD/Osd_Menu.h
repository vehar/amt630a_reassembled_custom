/*
  OSD����ͷ�ļ���
*/
#ifndef _OSD_MENU_H__
#define _OSD_MENU_H__

#ifdef _OSD_MENU_C
#define _OSD_MENU_EXTERN_ 
#else
#define _OSD_MENU_EXTERN_  extern
#endif

#define FONT_RAM_INDEX_STAR_ADDR 0X2E0
#define ICONBITMAP_SATRT_INDEX  40
#define LOGOBITMAP_SATRT_INDEX  0


typedef enum 
{
	ENGLISH  = 0,         
	FRENCH,   
	ITALIAN ,   
	SPANISH,	
	GERMAN,      
	PUTOYA,
	DUTCH, 		 
	RUSSIAN, 
	CHINESE ,    
	JAPANESE,  
	BULGARIAN,	//����������
	POLISH	,	//������
	TURK   ,    //��������
	
	MIN_LAG = ENGLISH,
	MAX_LANG = TURK,
}MultLanguageType;

typedef enum
{
	TRANSPARENCE = 0,             
	RED,          
	GREEN,          
	BLUE ,         
	YELLOW ,            
	GRAY ,      
	WHITE,     
	BLACK,
	MAX_COLOR = -1,
} ColorType;

typedef enum
{ 
	Osd_PowerOffMenu=0, 
	Osd_PowerOnMenu,	
	Osd_RootMenu, 
	
	/*һ�����û��Զ���˵�*/
    Osd_LOGO1Menu,
    Osd_LOGO2Menu,
    Osd_LOGO3Menu,
    Osd_LOGO4Menu,
    Osd_LOGO5Menu,
	Osd_QuicklyBrightnessMenu,
    Osd_QuicklyContrastMenu,
    Osd_QuicklySaturationMenu,
    Osd_BrightnessMenu,
    Osd_ContrastMenu,
    Osd_SaturationMenu,
    Osd_BatteryAdcMenu,
	Osd_MaxMenu
} MenuPageIndexType;

typedef enum
{
    OsdBlock0,
   	OsdBlock1,
   	OsdBlock2,
   	OsdBlock3,
   	OsdBlock4,
}OsdBlockType;


typedef enum  _CommandType
{ 
  COMD_Nothing,
  COMD_NextMenu,	
  COMD_PrevMenu, 
  COMD_IncValue, 
  COMD_DecValue,
  COMD_Brightness,
  COMD_BrightnessInc,
  COMD_BrightnessDec,
  COMD_Contrast,
  COMD_ContrastInc,
  COMD_ContrastDec,
  COMD_Saturation,
  COMD_SaturationInc,
  COMD_SaturationDec,
  COMD_OsdExit,  
  COMD_OsdStorage,
  COMD_RedrawMenu,
  COMD_SelPowerOnMode,
  COMD_Power,
  COMD_RedrawLogo,
  COMD_ClearLogo,
  COMD_BatteryAdc,
  COMD_TurnOnBackLight,
  COMD_TurnOffBackLight,
  COMD_OvpBackLight,
  COMD_BlockTurn,
  COMD_BlockDown,
  COMD_BlockLeft,
  COMD_BlockRight,
} ComdType;

#define osdInvisible    _BIT0
#define osdVisible      _BIT1
#define osdRedraw       _BIT2
#define osdEnd 		    _BIT3
#define osdDecNum       _BIT4
#define osdHexNum       _BIT5
#define osdSel          _BIT6
#define osdDraw         _BIT7

typedef struct
{
    UCHAR Flags; 
	CHAR XPos,YPos; 
}AdjustType;

typedef UCHAR* (*fpDisplayText)(void);
typedef BOOL (*fpExecFunc)(void);
typedef BYTE (*fpItemIndex)(void);
typedef BOOL (*fpAdjustValue)(ComdType opratComd);
typedef UINT (*fpGetValue)(void);
typedef UINT (*fpGetMaxValue)(void);
typedef UINT (*fpSetMaxValue)(void);
typedef UINT* (*fpDisplayIcon)(void);
typedef AdjustType (*fpCheckCondition)(void);
typedef BOOL (*fpDrawStyle)(void);



typedef enum
{ 
	DWT_Nothing,
	DWT_Text,
	DWT_FullText,
	DWT_CenterText,
	DWT_FullCenterText,
	DWT_None
} DrawTitelType;


typedef struct
{
    UCHAR       cConditions;           
    ComdType    Comd;     
    MSG         Msg;
    UCHAR       Source;
} KeyComdInterface;



typedef struct
{ 
	UCHAR XPos, YPos;
	UCHAR ForeColor, BackColor;
	UCHAR SelForeColor, SelBackColor;
	fpGetValue GetValue;   
	UINT  Flags;	
} DrawNumberType;

typedef struct
{ 	
	UCHAR XPos, YPos;
	UCHAR ForeColor, BackColor;
	UCHAR SelForeColor, SelBackColor;
	UCHAR Length;
	fpGetValue GetValue;
	UINT  Flags;	
} DrawGuageType;


typedef struct
{ 	
	UCHAR XPos, YPos;
	UCHAR ForeColor, BackColor;
	UCHAR SelForeColor, SelBackColor;
	fpGetValue GetValue;
	fpDisplayText DisplayText;    
	UINT  Flags;	
} DrawOptionType;

typedef struct
{ 
	DrawNumberType* DrawNumber;
	DrawGuageType*  DrawGuage;
	DrawOptionType* DrawOption;	
	UINT  Flags;
} ItemValueType;

typedef struct
{
	UCHAR  XPos , YPos;
	UCHAR  ForeColor, BackColor;
	UCHAR  SelForeColor, SelBackColor;
	DrawTitelType DrawTitelMethod;
	fpDisplayText  DisplayText; 
    UINT  Flags;
}TitelType;


typedef struct
{
	UCHAR  XPos , YPos;
	UCHAR  XSize, YSize;
	UCHAR  BackColor;
	UCHAR  SelBackColor;
	fpDisplayIcon  DispalyIcon; 
	UINT   Flags;
}IconType;

typedef struct
{
	CHAR* ItemName;
    UCHAR XPos , YPos;
	
	fpCheckCondition CheckCondition;  //�������,��������ӦУ��ϵ����
	fpDrawStyle    DrawItemStyle;     //��Ŀ���
	IconType*      ItemIcons;	      //��Ŀͼ��
	TitelType*     ItemTitels;         //��Ŀ����
	ItemValueType* ItemValue;         //��Ŀ��ֵ(���֣���������ѡ��)
	
	fpAdjustValue AdjustFunction;
	fpExecFunc    ExecFunction;
	
	KeyComdInterface* KeyComdMap;	
	UCHAR  ComdCount;
	
	UINT  Flags;
} MenuItemType;

typedef struct
{ 
    CHAR* MenuName;
    UINT  XPos , YPos;
	UCHAR  XSize, YSize;
	UCHAR  ForeColor, BackColor;
	UCHAR  OsdBlockId;
	
	UCHAR  PrevPage;
	UCHAR  CurrentPage;
	UCHAR  NextPage;

	
	
    fpCheckCondition CheckCondition;  //�������,��������ӦУ��ϵ����
	fpDrawStyle   DrawMenuStyle;      //�˵����Է��
	IconType*     MenuIcons;          //�˵�ͼ��
	TitelType*    MenuTitels;         //�˵�����
	MenuItemType* MenuItems;          //�˵���Ŀ
	UCHAR ItemCount;
	
	fpExecFunc   ExecFunction;        //�˵�ִ�к���,�Եײ�������� 
   	
	UINT   TimeOut;
	UINT  Flags;
} MenuPageType;

_OSD_MENU_EXTERN_ BYTE XDATA g_ucMenuPageIndex;
_OSD_MENU_EXTERN_ BYTE XDATA g_ucMenuItemIndex;


_OSD_MENU_EXTERN_ UCHAR KeyMsgProcess(MSG curMsg);
_OSD_MENU_EXTERN_ void  MenuProcessKey(BYTE OpratComd);

//===============================================================
_OSD_MENU_EXTERN_ void  DrawOsdMenu(void);
_OSD_MENU_EXTERN_ void  LoadIconToFontRam(UCHAR Index,UCHAR IconXSize,UCHAR IconYSize,UCHAR*IconBuf[]);
_OSD_MENU_EXTERN_ void  DrawOsdMenuItemValue(ItemValueType* pItemValue,UINT status);
_OSD_MENU_EXTERN_ UCHAR GetPreMenu(void);
_OSD_MENU_EXTERN_ UCHAR GetNextMenu(void);
_OSD_MENU_EXTERN_ void  DrawOsdMenuItem(MenuItemType *pMenuItem,UINT status) reentrant;
_OSD_MENU_EXTERN_ void DrawOsdTitel(TitelType *pTitel,UINT status);
_OSD_MENU_EXTERN_ UCHAR FindMenuPageIndex(UCHAR menuPage);
_OSD_MENU_EXTERN_ void  ConfigOsdBlockStarIndexAddr(void);
_OSD_MENU_EXTERN_ UCHAR FindComdInCurMenuItem(MSG curMsg);
_OSD_MENU_EXTERN_ void HideMenu(void);
_OSD_MENU_EXTERN_ void ResetMenuIndex(void);
_OSD_MENU_EXTERN_ void SetMenuIndex(UCHAR menuPage);
_OSD_MENU_EXTERN_ void DMALoadFontRam(ULONG SrcAddr,UINT DstAddr,UINT numOper);
_OSD_MENU_EXTERN_ BOOL ExectComd(ComdType OpratComd);

#endif
