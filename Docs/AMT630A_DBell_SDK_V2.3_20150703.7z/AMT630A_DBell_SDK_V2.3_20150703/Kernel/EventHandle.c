/***********************************************************************
*Copyright (C) 2005 ���ڰ��ƴ������޹�˾��ƷӦ��һ��
* All rights reserved.

*File name: �� ArkRun.c
*Version:    ��0.1
*Author:       cjinzong
*update:       2011-11-26

*Description:
              ϵͳ��ģ�������߼���
*History:  

************************************************************************/
#define _EVENT_HANDLE_C_

/* include head file s*/
#include "DataType.h"
#include "SystemConfig.h"
#include "Global.h"
#include "MsgMap.h"
#include "Osd_Menu.h"
#include "configLcdPara.h"
#include "EventHandle.h"
#include "Debug.h"
#include "Delay.h"
#include "VideoProc.h"
#include "sysPower.h" 
#include "AMT_Reg.h"
#include "AMT_Drv.h"
#include "AMT_Mcu.h"



/***********************************************************
*name:       OsdMsgHandle(MSG curMsg)
*input:      curMsg
*output:     void 

*update:     2011-11-27 
*state:      allright

*description:   
          �����û���Ϣ����Ҫ�ǰ�����ң������
          ��Ҫ���Ǵ˴���OSD�Ľӿڣ����ҿ���ʵ��OSD�ķ���л���
*history:
                                
************************************************************/
void  OsdMsgHandle(MSG curMsg)
{
    UCHAR ucComd= COMD_Nothing;
	
    ucComd = KeyMsgProcess(curMsg);	

	if(ucComd!= COMD_Nothing)
	{
	  g_ucContNoSignalSecond = 0X00;
      g_sysSetting.Osd.storageTime = 0X00;
	}
	
    MenuProcessKey(ucComd);
}


/***********************************************************
*name:       SignalMsgHandle(MSG curMsg)
*input:      curMsg
*output:     void 

*update:     2011-11-27 
*state:      allright

*description:   
          �����źŵ���Ϣ����Ҫ�д����źŵ����źţ������źŵ����ź�
          ��������Ϣ���ź����ȼ���Ϣ �ȵȡ���
*history:
                                
************************************************************/
void  SignalMsgHandle(MSG curMsg)
{

     if(curMsg == MSG_SIGNAL_OK)
     {
        printfStr("MSG_SIGNAL_OK");
		
        #ifdef NoSignalBLOffEn
	    ExectComd(COMD_TurnOnBackLight); 
		#endif

		#ifdef LogoEn 
		g_bLogoDisplayFlag = 0;
		
		#if (LOGO_DISP_MODE == NOSIGNAL_DISP_LOGO)
		ExectComd(COMD_ClearLogo); 
		#endif
		
		#endif

     }

	 if(curMsg == MSG_NO_SIGNAL)
	 {  
	    printfStr("MSG_NO_SIGNAL");

	    #ifdef NoSignalBLOffEn
	    ExectComd(COMD_TurnOffBackLight);
		#endif

		#ifdef LogoEn 
		g_bLogoDisplayFlag = 1;
		
		#if (LOGO_DISP_MODE == NOSIGNAL_DISP_LOGO)
		ExectComd(COMD_RedrawLogo); 
		#endif
		
		#endif
	 }
}
/***********************************************************
*name:       ColorSysMsgHandle(MSG curMsg)
*input:      curMsg
*output:     void 

*update:     2011-11-27 
*state:      allright

*description:   
         ����ͼ��Ч����Ϣ����Ҫ�Ǹ��ݵ�ǰͨ����ͼ����ʽ������
         ��Ӧ��ͼ������� 
*history:
                                
************************************************************/
void  ColorSysMsgHandle(MSG curMsg)
{
     if(curMsg == MSG_CONFIG_COLOR_SYS)
     {   
		ConfigColorSysDynPara(g_sysSetting.Video.colorSys); 
     }
}

/***********************************************************
*name:       TimeMsgHandle(MSG curMsg)
*input:      curMsg
*output:     void 

*update:     2011-11-27 
*state:      allright

*description:   
         ����ϵͳ����ʱ����Ϣ����Ҫ�ж�ʱ���ػ�����ʱ˯��ģʽ��
         
*history:
                                
************************************************************/
void  TimeMsgHandle(MSG curMsg)
{
			
    if(MSG_OSD_EXIT == curMsg) 
    {
        printfStr("MSG_OSD_EXIT");
        MenuProcessKey(COMD_OsdExit);
    }

	if(MSG_OSD_STORAGE == curMsg) 
    {   
        printfStr("MSG_OSD_STORAGE");
        MenuProcessKey(COMD_OsdStorage);
    }
		
	if(MSG_NOSIGNALPOWEROFF == curMsg) 
    {   
        printfStr("MSG_NOSIGNALPOWEROFF");
		MenuProcessKey(COMD_Power);
    }
}


/***********************************************************
*name:       BatteryAdcMsgHandle(MSG curMsg)
*input:      curMsg
*output:     void 

*update:     2011-11-27 
*state:      allright

*description:   
         ����ϵͳ��ص�ʵʱ��ѹ��Ϣ��
         
*history:
                                
************************************************************/
void  BatteryAdcMsgHandle(MSG curMsg)
{
    if(MSG_BATTERYADC == curMsg) 
    {
        printfStr("MSG_BATTERYADC");
        MenuProcessKey(COMD_BatteryAdc);
    }
}



/***********************************************************
*name:       UserDefinedMsgHandle(MSG curMsg)
*input:      curMsg
*output:     void 

*update:     2011-11-27 
*state:      allright

*description:   
        �����û��Զ�����Ϣ
         
*history:
                                
************************************************************/
void  UserDefinedMsgHandle(MSG curMsg)
{

	if(MSG_TURNON_BACKLIGHT == curMsg) 
    {   
        printfStr("MSG_TURNON_BACKLIGHT");
        ExectComd(COMD_TurnOnBackLight);
    }
		
    if(MSG_TURNOFF_BACKLIGHT == curMsg) 
    {   
        printfStr("MSG_TURNOFF_BACKLIGHT");
        ExectComd(COMD_TurnOffBackLight);
    }    
}

