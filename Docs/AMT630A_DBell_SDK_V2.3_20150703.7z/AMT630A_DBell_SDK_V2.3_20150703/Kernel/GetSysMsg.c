/***********************************************************************
*Copyright (C) 2005 ���ڰ��ƴ������޹�˾��ƷӦ��һ��
* All rights reserved.

*File name: �� GetSysMsg.c
*Version:    ��0.1
*Author:       cjinzong
*update:       2011-12-09

*Description:
             ���ļ���ϵͳ�ɼ���Ϣ��ϵͳ���е���Ϣ�������ɴ��ļ�������
*History:  

************************************************************************/
#define _GET_MSG_C_

#include "DataType.h"
#include "systemConfig.h"
#include "global.h"
#include "MsgMap.h"
#include "debug.h"
#include "mcu.h"
#include "GetUserInputMsg.h"
#include "GetSysMsg.h"
#include "ConfigLcdPara.h"
#include "interrupt.h"
#include "delay.h"
#include "Osd_Menu.h"
#include "Osd_MenuPage.h"
#include "AMT_Reg.h"
#include "AMT_Drv.h"
#include "AMT_Mcu.h"
#include "SysPower.h"
#include "BatteryAdc.h"



/***********************************************************
*name:       POS_GetUserInputMsg(void)
*input:      timeflg  //��ʱʱ���־
*output:     void 
*update:     2011-11-27 
*state:      allright

*description:   
          ��ȡ�û�������Ϣ����Ҫ�а�����ң��������Ϣ��
          
*history:

************************************************************/
MSG POS_GetUserInputMsg(void)
{
    MSG XDATA curInputMsg = MSG_NULL;

    #ifdef KeyDetectEn
	curInputMsg = POS_GetKeyPadMsg();
	
	if(curInputMsg != MSG_NULL)
	{  			
	   return curInputMsg;
	}
    #endif
	
	return curInputMsg;
}



/***********************************************************
*name:       POS_GetSignalMsg(timeflg)
*input:      timeflg  //��ʱʱ���־
*output:     void 
*update:     2011-11-27 
*state:      allright

*description:   
          ��ȡ�ź�״̬��Ϣ����Ҫ�Ǽ���ź����ޣ��ź�ǿ����״̬��
          
*history:

************************************************************/
MSG POS_GetSignalMsg(FLAG timer)
{
#define DetecTimes   20

	static UCHAR XDATA ucCont = 0;
	static FLAG   bSignalFlg = FALSE;
	
	if(timer)
	{
	    g_bGetSignalFlg = 0;

		#ifndef NoSignalBLOffEn
        //�����źż��
		if(bSignalFlg == ((COLOR_SYS_TV_ACTIVE&_BIT1)>>1))
		{   
			if(ucCont<DetecTimes)
			{
			    ucCont++; 
				if(ucCont == DetecTimes)
				{
				     if(bSignalFlg)
				     {   
				         return MSG_SIGNAL_OK; //�ɿ����ź�
				     }
					 else
					 {   
					     return MSG_NO_SIGNAL;//���ź�
					 }
				}
			}
		}
		else
		{
		    ucCont = 0; 
		    bSignalFlg = (COLOR_SYS_TV_ACTIVE&_BIT1)>>1;
		}
        #else
		if(!IsSignalOk())
		{
	        SelAvSOGIn();
	        SelNullChannel();
			if(bSignalFlg == ((COMPHV_DETECT & _BIT6)>>6))
			{
			   	if(ucCont<DetecTimes)
				{
				    ucCont++; 
					if(ucCont == DetecTimes)
					{
					     if(bSignalFlg)
					     {   
					         return MSG_SIGNAL_OK; //�ɿ����ź�
					     }
						 else
						 {   
						     return MSG_NO_SIGNAL;//���ź�
						 }
					}
				}
			}
			else
			{
			    ucCont = 0; 
			    bSignalFlg = (COMPHV_DETECT&_BIT6)>>6;
			}
		}
		#endif
	}
	return MSG_NULL;
}

/***********************************************************
*name:       POS_GetColorSysMsg(timeflg)
*input:      timeflg  //��ʱʱ���־
*output:     void 
*update:     2011-11-27 
*state:      allright

*description:   
          ��ȡͼ����ʽ��Ϣ������PAL/NTSC/SECAM���л�������ͼ��Ч����
          
*history:

************************************************************/
MSG POS_GetColorSysMsg(FLAG timer)
{
	if(timer)
	{
		g_bGetColorSysFlg = 0;
		
	    if((g_ucColorSys != g_ucPreColorSys))
	    {
	        g_ucPreColorSys = g_ucColorSys;
			if(g_ucColorSys != NULL_SYS)  
	        {
	        	g_sysSetting.Video.colorSys = g_ucColorSys;
				//printf("g_sysSetting.Video.colorSys =%x", g_sysSetting.Video.colorSys);
				if(g_sysSetting.Video.colorSys < AUTO)
				{
				     return MSG_CONFIG_COLOR_SYS; 
	            }
				else
				{
				     return MSG_NULL;
				}
	        }
	    }
	}
	return MSG_NULL;    
}



/***********************************************************
*name:       POS_GetTimeMsg(timeflg)
*input:      timeflg  //��ʱʱ���־
*output:     void 
*update:     2011-11-27 
*state:      allright

*description:   
          ��ȡϵͳʱ����Ϣ�����綨ʱ����
          
*history:

************************************************************/
MSG POS_GetTimeMsg(FLAG timer)
{
	if(timer)
	{  
		g_bGetTimeFlg = 0;
		if(g_sysSetting.Osd.dispTime>0)
		{   
		    if(--g_sysSetting.Osd.dispTime == 0)
		    {    
		         /*�ڴ��ж��Ƿ���Ҫ�˳�OSD ������Ҫ��ʾLOGO�������˵�*/
                 return MSG_OSD_EXIT;
		    }
		}

	    #ifdef QuickParaSaveEn 
        if(g_sysSetting.Osd.storageTime < OSD_STORAGE_TIME)  
        {
			if(++g_sysSetting.Osd.storageTime == OSD_STORAGE_TIME)
            {
                /*�ڴ��ж��Ƿ���Ҫ���ټ���OSD����*/
                return(MSG_OSD_STORAGE);
            }
        }
		#endif
		
		#ifdef NoSignalPowerOffEn
		#define NoSignalSecond          2
		if(IsPowerOn()&&!IsSignalOk())
		{
			if(POS_SysTimeDriver())
			{
			    if(g_ucContBufSecond >= 60)
			    {
			        g_ucContBufSecond -= 60;
					g_ucContNoSignalSecond++;

				    if(g_ucContNoSignalSecond >= NoSignalSecond)
					{
					    return MSG_NOSIGNALPOWEROFF;
					}
			    }
			}
		}
		else
		{
		    g_ucContNoSignalSecond = 0X00;
		}
		#endif
	}
	return MSG_NULL;       
}



/***********************************************************
*name:       POS_GetBatteryAdcMsg(timeflg)
*input:      timeflg  //��ʱʱ���־
*output:     void 
*update:     2011-11-27 
*state:      allright

*description:   
          ��ȡϵͳ��ص�ʵʱ��ѹ��Ϣ��
          
*history:

************************************************************/
MSG POS_GetBatteryAdcMsg(FLAG timer)
{

	UINT  XDATA curBatteryAdcVal = NULL_BATTERYADC;

    if(timer)
    {
        g_bGetBatteryAdcFlg = 0;

		#ifdef LowBaterryDetecEn 
		curBatteryAdcVal = POS_GetBatteryAdcValue();
		if(NULL_BATTERYADC != curBatteryAdcVal)
		{
             g_ucBatteryAdcVal = curBatteryAdcVal & 0X00FF; 
             return MSG_BATTERYADC;
		}
		#endif
    }
    return MSG_NULL;  
}



/***********************************************************
*name:       POS_GetUserDefinedMsg(timeflg)
*input:      timeflg  //��ʱʱ���־
*output:     void 
*update:     2011-11-27 
*state:      allright

*description:   
         ��ȡ�û��Զ�����Ϣ������һЩIO��״̬ �ȵ�ʵʱ������Ϣ��
          
*history:

************************************************************/
MSG POS_GetUserDefinedMsg(FLAG timer)
{

	if(timer)
	{
		g_bGetUserDefFlg = 0;

		#ifdef SignalChangeBLOffEn
		//��������������£��źű仯ʱ�����Ժ�����һ��ʱ����
		if(g_ucContBLOn > 0)
		{   
	        g_ucContBLOn--;
			if(g_ucContBLOn == 0)
			{
	             if(g_bSignalFlg)
				 {
				     //�ȴ�Thlen �Զ��������
				     while(XBYTE[0XFCE7]&_BIT3);
                     SetVDETestSwitch(VDE_CLOSE);
				 }
				 else
				 {
                     SetVDETestSwitch(VDE_BLUE);
				 }
				 TurnOnBackLight(); 			
			}
		}
		#endif

		
		#ifdef BL_OvpSoftProtecEn 
		if(g_bReleaseAdcKeyFlg)
		{
		    #define BLOvpSofProtec    3
		    static UCHAR XDATA BLOvpSofProtecStateCnt = 0;
			
		    if(POS_EnableChipAdc(ADC_DETEC_CH) > ProtecVolteAdcVal(ProtecVolte))
			{
			    BLOvpSofProtecStateCnt++;
			}
			else
			{
			   BLOvpSofProtecStateCnt = 0;
			}
            if(BLOvpSofProtecStateCnt >= BLOvpSofProtec)
            {
               return MSG_TURNOFF_BACKLIGHT;
            }
		}
		#endif

	}
	return MSG_NULL;  
}
