
#include "DataType.h"
#include "systemConfig.h"
#include "global.h"


#if P_AT070TN92_AMT630A_STD_20141202_EN
#include "P_AT070TN92_AMT630A_STD_20141202.c"
#endif

#if P_SAT043CM40DMY0_AMT630A_STD_20141202_EN
#include "P_SAT043CM40DMY0_AMT630A_STD_20141202.c"
#endif

#if P_AT070TN92_AMT630A_STD_20141219_EN
#include "P_AT070TN92_AMT630A_STD_20141219.c"
#endif