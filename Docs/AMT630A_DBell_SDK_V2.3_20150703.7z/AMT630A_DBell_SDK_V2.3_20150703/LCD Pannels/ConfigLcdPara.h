/***********************************************************************
*Copyright (C) 2011 ���ڰ��ƴ������޹�˾��ƷӦ���Ĳ�
* All rights reserved.

*File name: �� ConfigLcdPara.h
*Version:    ��0.1
*update:       2011-11-28

*Description:
             ����ļ����ṩ�����β����Ľӿڡ�
             
*History:  yshuizhou   2011/12/06    0.1    build  this  moudle
************************************************************************/
#ifndef _CONFIGLCDPARA_H_
#define _CONFIGLCDPARA_H_


#ifdef _CONFIGLCDPARA_C_
#define CONFIGLCDPARA_EXTERN_   
#else
#define CONFIGLCDPARA_EXTERN_ extern
#endif



CONFIGLCDPARA_EXTERN_ UCHAR XDATA  g_ucbrightness;
CONFIGLCDPARA_EXTERN_ UCHAR XDATA  g_ucContrast;
CONFIGLCDPARA_EXTERN_ UCHAR XDATA  g_ucSaturation;
CONFIGLCDPARA_EXTERN_ UCHAR XDATA  g_ucAdjustBrightnessVal;
CONFIGLCDPARA_EXTERN_ UCHAR XDATA  g_ucAdjustContrastVal;
CONFIGLCDPARA_EXTERN_ UCHAR XDATA  g_ucAdjustSaturationVal;
CONFIGLCDPARA_EXTERN_ UCHAR CODE   g_ucPalPllClkDefVal;
CONFIGLCDPARA_EXTERN_ UCHAR CODE   g_ucNtscPllClkDefVal;

CONFIGLCDPARA_EXTERN_ void UpdataPicPara(void);
CONFIGLCDPARA_EXTERN_ void ConfigDispZoomDynPara(UCHAR currentmode);
CONFIGLCDPARA_EXTERN_ void ConfigColorSysDynPara(UCHAR currentSys);
CONFIGLCDPARA_EXTERN_ UCHAR GetSourceID(UCHAR CurretSource);
CONFIGLCDPARA_EXTERN_ void ConfigStaticPara(UCHAR CurretSource);
CONFIGLCDPARA_EXTERN_ void ConfigPadMuxPara(void);
CONFIGLCDPARA_EXTERN_ void ConfigUserParaSetting(void);

#endif

