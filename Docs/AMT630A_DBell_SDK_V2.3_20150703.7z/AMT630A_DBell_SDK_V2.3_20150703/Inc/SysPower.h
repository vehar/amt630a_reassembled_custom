/***********************************************************************
*Copyright (C) 2005 ���ڰ��ƴ������޹�˾��ƷӦ��һ��
* All rights reserved.

*File name: �� SysPower.h
*Version:    ��0.1
*Author:       Jordan.chen
*update:       2011-12-07

*Description:
           ���ļ�Ϊϵͳ��Դģ��ͷ�ļ���
*History:  

************************************************************************/
#ifndef _SYSPOWER_H__
#define _SYSPOWER_H__


#ifdef _POWER_C_
  #define _POWER_EXTERN_   
#else
  #define _POWER_EXTERN_ extern
#endif




/*=========================��Դ����==========================*/

#define IsPowerOn() (g_sysSetting.Power.status== POWER_ON)
#define IsPowerOff()(g_sysSetting.Power.status == POWER_OFF)
#define SetPowerOn() (g_sysSetting.Power.status = POWER_ON)
#define SetPowerOff() (g_sysSetting.Power.status = POWER_OFF)

_POWER_EXTERN_ BOOL PowerOnSystem(void);
_POWER_EXTERN_ BOOL PowerOffSystem(void);
#endif
