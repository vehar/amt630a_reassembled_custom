#include"DataType.h"
#include "systemConfig.h"
UCHAR* CODE Switch_SelectLogoIdStr[] = 
{ 
"     ARK",
"    Auto",
};