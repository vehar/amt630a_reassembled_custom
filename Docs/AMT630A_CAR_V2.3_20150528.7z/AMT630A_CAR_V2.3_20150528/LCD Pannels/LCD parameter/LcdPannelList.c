
#include "DataType.h"
#include "systemConfig.h"
#include "global.h"


#if P_MEX070TM_50D_DHV_AMT630A_20141113_EN
#include "P_MEX070TM_50D_DHV_AMT630A_20141113.c"
#endif

#if P_SAT043CM40DMY0_AMT630A_STD_20141202_EN
#include "P_SAT043CM40DMY0_AMT630A_STD_20141202.c"
#endif


