/***********************************************************************
*Copyright (C) 2005 ���ڰ��ƴ������޹�˾��ƷӦ��һ��
* All rights reserved.

*File name: �� ArkChip.c
*Version:    ��1.0
*Author:       cjinzong
*update:       2010-05-27

*Description:
*History:  
   
************************************************************************/

#include "DataType.h"
#include "SystemConfig.h"
#include "Global.h"
#include "Mcu.h"
#include "Debug.h"
#include "IrMap.h"
#include "ConfigLcdPara.h"
#include "MsgMap.h"
#include "Osd_Menu.h"
#include "Osd_MenuPage.h"
#include "Ir.h"
#include "Delay.h"



#include "AMT_Drv.c"
#include "AMT_OsdBootDrv.c"

